DELIMITER //

CREATE PROCEDURE sp_products_list()
BEGIN
    SELECT p.product_id, p.name, c.name AS category_name, p.price, p.stock
    FROM products p
    JOIN categories c ON p.category_id = c.category_id;
END //

CREATE PROCEDURE sp_product_add(
    IN p_name VARCHAR(255),
    IN p_category_id INT,
    IN p_price DECIMAL(10,2),
    IN p_stock INT,
    OUT p_product_id INT
)
BEGIN
    INSERT INTO products (name, category_id, price, stock)
    VALUES (p_name, p_category_id, p_price, p_stock);
    SET p_product_id = LAST_INSERT_ID();
END //

CREATE PROCEDURE sp_product_update_price(
    IN p_product_id INT,
    IN p_new_price DECIMAL(10,2)
)
BEGIN
    UPDATE products SET price = p_new_price WHERE product_id = p_product_id;
END //

CREATE PROCEDURE sp_category_stats()
BEGIN
    SELECT 
        c.name AS category_name,
        COUNT(p.product_id) AS products_count,
        IFNULL(SUM(oi.quantity), 0) AS sold_units,
        IFNULL(SUM(oi.quantity * oi.price), 0) AS revenue
    FROM categories c
    LEFT JOIN products p ON c.category_id = p.category_id
    LEFT JOIN order_items oi ON p.product_id = oi.product_id
    GROUP BY c.category_id, c.name;
END //

CREATE PROCEDURE sp_order_create(
    IN p_customer_id INT,
    OUT p_order_id INT
)
BEGIN
    INSERT INTO orders (customer_id, total_amount) VALUES (p_customer_id, 0.00);
    SET p_order_id = LAST_INSERT_ID();
END //

CREATE PROCEDURE sp_order_add_item(
    IN p_order_id INT,
    IN p_product_id INT,
    IN p_quantity INT,
    OUT p_success INT,
    OUT p_message VARCHAR(255)
)
BEGIN
    DECLARE v_stock INT;
    DECLARE v_price DECIMAL(10,2);
    
    START TRANSACTION;
    
    SELECT stock, price INTO v_stock, v_price FROM products WHERE product_id = p_product_id FOR UPDATE;
    
    IF v_stock >= p_quantity THEN
        INSERT INTO order_items (order_id, product_id, quantity, price)
        VALUES (p_order_id, p_product_id, p_quantity, v_price);
        
        UPDATE products SET stock = stock - p_quantity WHERE product_id = p_product_id;
        UPDATE orders SET total_amount = total_amount + (v_price * p_quantity) WHERE order_id = p_order_id;
        
        SET p_success = 1;
        SET p_message = 'Success';
        COMMIT;
    ELSE
        SET p_success = 0;
        SET p_message = 'Not enough stock available';
        ROLLBACK;
    END IF;
END //

CREATE PROCEDURE sp_customer_orders(IN p_customer_id INT)
BEGIN
    SELECT order_id, created_at, total_amount, 
           (SELECT IFNULL(AVG(total_amount), 0) FROM orders WHERE customer_id = p_customer_id) AS avg_check
    FROM orders 
    WHERE customer_id = p_customer_id;
END //
DELIMITER ;
