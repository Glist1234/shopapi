INSERT INTO categories (name) VALUES ('Электроника'), ('Книги'), ('Одежда');
INSERT INTO customers (first_name, last_name, email) VALUES ('Иван', 'Иванов', 'ivan@mail.ru'), ('Петр', 'Петров', 'petr@mail.ru');
INSERT INTO products (name, category_id, price, stock) VALUES ('Смартфон', 1, 25000.00, 10), ('Ноутбук', 1, 55000.00, 5), ('Роман 1984', 2, 450.00, 20);
