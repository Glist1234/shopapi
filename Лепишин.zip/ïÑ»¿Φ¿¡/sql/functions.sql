DELIMITER //
CREATE FUNCTION IF NOT EXISTS fn_customer_discount(p_customer_id INT, p_amount DECIMAL(10,2))
RETURNS INT
DETERMINISTIC
BEGIN
    DECLARE v_total_spent DECIMAL(10,2) DEFAULT 0.00;
    DECLARE v_discount INT DEFAULT 0;
    
    SELECT IFNULL(SUM(total_amount), 0) INTO v_total_spent 
    FROM orders 
    WHERE customer_id = p_customer_id;
    
    IF v_total_spent > 50000 THEN
        SET v_discount = 15;
    ELSEIF v_total_spent > 20000 THEN
        SET v_discount = 10;
    ELSEIF v_total_spent > 50000 THEN
        SET v_discount = 5;
    END IF;
    
    RETURN v_discount;
END //
DELIMITER ;
