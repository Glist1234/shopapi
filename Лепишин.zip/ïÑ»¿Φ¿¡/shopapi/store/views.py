from django.shortcuts import render, redirect
from django.contrib import messages
from django.db import connection
from .db import call_procedure, call_function

def _get_raw_list(query):
    with connection.cursor() as cursor:
        cursor.execute(query)
        return cursor.fetchall()

# Задание 1. Список товаров
def products_list(request):
    rows, _, error = call_procedure('sp_products_list')
    if error:
        messages.error(request, error)
        rows = []
    products = [
        {'id': r[0], 'name': r[1], 'category': r[2], 'price': r[3], 'stock': r[4]}
        for r in rows
    ] if rows else []
    return render(request, 'store/products_list.html', {'products': products})

# Задание 2. Добавление товара
def product_add(request):
    if request.method == 'POST':
        name = request.POST['name']
        category_id = int(request.POST['category_id'])
        price = float(request.POST['price'])
        stock = int(request.POST['stock'])
        
        _, out, error = call_procedure('sp_product_add', [name, category_id, price, stock], out_count=1, fetch=False)
        if error:
            messages.error(request, error)
            return redirect('product_add')
        
        messages.success(request, f'Товар #{out[0]} добавлен')
        return redirect('products_list')
        
    categories = _get_raw_list("SELECT category_id, name FROM categories")
    return render(request, 'store/product_add.html', {'categories': categories})

# Задание 3. Изменение цены
def product_update_price(request, pk):
    if request.method == 'POST':
        new_price = float(request.POST['price'])
        _, _, error = call_procedure('sp_product_update_price', [pk, new_price], fetch=False)
        if error:
            messages.error(request, error)
        else:
            messages.success(request, 'Цена товара успешно обновлена!')
        return redirect('products_list')
        
    with connection.cursor() as cur:
        cur.execute("SELECT product_id, name, price FROM products WHERE product_id = %s", [pk])
        prod = cur.fetchone()
    product = {'id': prod[0], 'name': prod[1], 'price': prod[2]} if prod else None
    return render(request, 'store/product_update_price.html', {'product': product})

# Задание 4. Создание заказа
def order_create(request):
    if request.method == 'POST':
        customer_id = int(request.POST['customer_id'])
        product_id = int(request.POST['product_id'])
        quantity = int(request.POST['quantity'])
        
        # Создание заказа
        _, out_order, error = call_procedure('sp_order_create', [customer_id], out_count=1, fetch=False)
        if error:
            messages.error(request, error)
            return redirect('order_create')
            
        order_id = out_order[0]
        
        # Добавление позиции с OUT параметрами p_success и p_message
        _, out_item, error = call_procedure('sp_order_add_item', [order_id, product_id, quantity], out_count=2, fetch=False)
        if error:
            messages.error(request, error)
            return redirect('order_create')
            
        success, message = out_item[0], out_item[1]
        if success == 1:
            messages.success(request, f'Заказ #{order_id} создан')
            return redirect('customer_orders', pk=customer_id)
        else:
            messages.error(request, f'Ошибка: {message}')
            return redirect('order_create')
            
    customers = _get_raw_list("SELECT customer_id, first_name, last_name FROM customers")
    products = _get_raw_list("SELECT product_id, name, stock FROM products")
    return render(request, 'store/order_create.html', {'customers': customers, 'products': products})

# Задание 5. Заказы клиента
def customer_orders(request, pk):
    rows, _, error = call_procedure('sp_customer_orders', [pk])
    if error:
        messages.error(request, error)
        rows = []
        
    with connection.cursor() as cur:
        cur.execute("SELECT first_name, last_name FROM customers WHERE customer_id = %s", [pk])
        cust = cur.fetchone()
    customer_name = f"{cust[0]} {cust[1]}" if cust else "Клиент"
    
    orders = []
    if rows:
        for r in rows:
            with connection.cursor() as cur:
                cur.execute("""
                    SELECT p.name, oi.quantity, oi.price 
                    FROM order_items oi 
                    JOIN products p ON oi.product_id = p.product_id 
                    WHERE oi.order_id = %s
                """, [r[0]])
                items = [{'name': row[0], 'qty': row[1], 'price': row[2]} for row in cur.fetchall()]
                
            orders.append({
                'id': r[0],
                'created_at': r[1],
                'total': r[2],
                'avg_check': r[3],
                'items': items
            })
            
    return render(request, 'store/customer_orders.html', {'orders': orders, 'customer_name': customer_name})

# Задание 6. Статистика по категориям
def category_stats(request):
    rows, _, error = call_procedure('sp_category_stats')
    if error:
        messages.error(request, error)
        rows = []
    stats = [
        {'category': r[0], 'products_count': r[1], 'sold_units': r[2], 'revenue': r[3]}
        for r in rows
    ] if rows else []
    max_revenue = max([s['revenue'] for s in stats]) if stats else 0
    return render(request, 'store/category_stats.html', {'stats': stats, 'max_revenue': max_revenue})

# Задание 7. Расчёт скидки
def discount_view(request):
    result = None
    if request.method == 'POST':
        customer_id = int(request.POST['customer_id'])
        amount = float(request.POST['amount'])
        percent = call_function('fn_customer_discount', [customer_id, amount])
        if percent is not None:
            total = amount * (1 - float(percent) / 100)
            result = {
                'customer_id': customer_id,
                'amount': amount,
                'percent': percent,
                'total': round(total, 2),
            }
    return render(request, 'store/discount.html', {'result': result})
