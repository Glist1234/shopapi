import os
import traceback
import logging
from django.db import connection, DatabaseError

# Настройка логирования ошибок БД
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

logger = logging.getLogger('db_errors')
logger.setLevel(logging.ERROR)
file_handler = logging.FileHandler(os.path.join(LOG_DIR, 'db_errors.log'), encoding='utf-8')
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)

def call_procedure(name, params=(), out_count=0, fetch=True):
    """
    Универсальный вызов хранимой процедуры по ТЗ.
    Возвращает (rows, out_values, error_message)
    """
    args = list(params) + [0] * out_count
    placeholders = ','.join(['%s'] * len(args))
    sql = f"CALL {name}({placeholders})"
    
    try:
        with connection.cursor() as cur:
            cur.execute(sql, args)
            rows = cur.fetchall() if fetch else None
            out_values = args[-out_count:] if out_count else []
            return rows, out_values, None
    except DatabaseError as e:
        error_tb = traceback.format_exc()
        logger.error(f"Ошибка в процедуре {name}: {e}\n{error_tb}")
        return None, [], f"Ошибка базы данных: {str(e)}"

def call_function(name, params=()):
    """Вызов хранимой функции, возвращающей скаляр по ТЗ."""
    placeholders = ','.join(['%s'] * len(params))
    sql = f"SELECT {name}({placeholders})"
    try:
        with connection.cursor() as cur:
            cur.execute(sql, list(params))
            res = cur.fetchone()
            return res[0] if res else None
    except DatabaseError as e:
        error_tb = traceback.format_exc()
        logger.error(f"Ошибка в функции {name}: {e}\n{error_tb}")
        return None
