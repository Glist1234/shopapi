from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect  # Этот импорт мы добавили, чтобы исправить ошибку

urlpatterns = [
    path('admin/', admin.site.urls),
    # Автоматический переброс с главной страницы на список товаров
    path('', lambda request: redirect('products_list')), 
    path('', include('store.urls')), 
]
