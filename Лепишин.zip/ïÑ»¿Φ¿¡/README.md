ShopAPI — Интернет-магазин на Django и MySQL
Инструкция по развертыванию базы данных:
1. Создайте базу данных в MySQL Workbench: CREATE DATABASE shop_django CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
2. Поочередно выполните SQL-файлы из папки sql/ в следующем порядке: сначала структуру таблиц (schema.sql), затем функции (functions.sql), после них процедуры (procedures.sql) и в конце тестовые данные (seed.sql).
Установка зависимостей проекта:
Убедитесь, что вы активировали виртуальное окружение, и выполните в терминале команду:
pip install django pymysql python-dotenv
Настройка окружения:
Создайте в корне файл .env и укажите параметры подключения (используйте строго цифровой хост 127.0.0.1 для высокой скорости работы в Windows):
• DB_NAME=shop_django
• DB_USER=root
• DB_PASSWORD=1234
• DB_HOST=127.0.0.1
• DB_PORT=3306




ИНСТРУКЦИЯ ПО РАЗВЕРТЫВАНИЮ ПРОЕКТА SHOPAPI
1. Развертывание базы данных:
• Откройте СУБД MySQL (например, MySQL Workbench) и создайте базу данных:
CREATE DATABASE shop_django CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
• Поочередно откройте и выполните SQL-скрипты из папки проекта /sql в следующем порядке:
1. schema.sql (создание таблиц)
2. functions.sql (создание хранимых функций)
3. procedures.sql (создание хранимых процедур)
4. seed.sql (наполнение тестовыми данными)
5. Установка зависимостей:
• Убедитесь, что вы используете стабильную версию Python (рекомендуется 3.11 или 3.12).
• Создайте и активируйте виртуальное окружение в терминале:
python -m venv venv
venv\Scripts\activate
• Установите пакеты Django, python-dotenv и драйвер pymysql:
pip install django python-dotenv pymysql
3. Настройка окружения:
• В корневом каталоге проекта создайте файл .env и укажите параметры подключения:
DB_NAME=shop_django
DB_USER=root
DB_PASSWORD=1234
DB_HOST=127.0.0.1
DB_PORT=3306
4. Запуск проекта:
